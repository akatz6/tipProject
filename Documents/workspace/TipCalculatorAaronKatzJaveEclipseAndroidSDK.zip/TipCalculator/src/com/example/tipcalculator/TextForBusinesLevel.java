package com.example.tipcalculator;

public enum TextForBusinesLevel {
	NUMGUESTS,
	BILL,
	TAX,
	DEDUCTIONS,
	STARS,
	TIPRATE,
	TOTALTIP,
	TIPPERPERSON,
	TOTALBILL
}