package com.example.tipcalculator;

public enum Text {
	NUMGUESTS,
	BILL,
	TAX,
	DEDUCTIONS,
	STARS,
	TIPRATE,
	TOTALTIP,
	TIPPERPERSON,
	TOTALBILL
}


